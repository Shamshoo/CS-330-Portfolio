///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for loading the texture image files
 *  used in the 3D scene into memory and binding them to
 *  OpenGL texture slots.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// wood grain for the desk surface
	bReturn = CreateGLTexture(
		"../../Utilities/textures/rusticwood.jpg",
		"desk");

	// soft white texture for the fabric lamp shade
	bReturn = CreateGLTexture(
		"../../Utilities/textures/drywall.jpg",
		"shade");

	// straight brushed gold for the lamp poles and the lip around the base
	bReturn = CreateGLTexture(
		"../../Utilities/textures/gold-seamless-texture.jpg",
		"gold");

	// circular brushed gold for the domed lamp bases
	bReturn = CreateGLTexture(
		"../../Utilities/textures/circular-brushed-gold-texture.jpg",
		"goldbase");

	// brushed metal for the monitor stand and clamp
	bReturn = CreateGLTexture(
		"../../Utilities/textures/stainless.jpg",
		"metal");

	// dark mottled image used as the monitor screen
	bReturn = CreateGLTexture(
		"../../Utilities/textures/backdrop.jpg",
		"screen");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the material settings
 *  for the objects in the 3D scene, which controls how each
 *  surface reacts to the light sources.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// wood desk - some specular so the lamp light reflects off the plane
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.ambientStrength = 0.5f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	woodMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	woodMaterial.shininess = 2.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// brushed gold and steel - highest shine for the metal parts
	OBJECT_MATERIAL goldMaterial;
	goldMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	goldMaterial.ambientStrength = 0.5f;
	goldMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	goldMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	goldMaterial.shininess = 4.0f;
	goldMaterial.tag = "gold";
	m_objectMaterials.push_back(goldMaterial);

	// fabric lamp shade - matte with almost no shine
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	fabricMaterial.ambientStrength = 0.5f;
	fabricMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	fabricMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	fabricMaterial.shininess = 0.5f;
	fabricMaterial.tag = "fabric";
	m_objectMaterials.push_back(fabricMaterial);

	// plastic for the keyboard, console and monitor frame - a soft shine
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	plasticMaterial.ambientStrength = 0.5f;
	plasticMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	plasticMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	plasticMaterial.shininess = 2.0f;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	// glass for the screen and candle holder - bright highlights
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	glassMaterial.ambientStrength = 0.5f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	glassMaterial.shininess = 6.0f;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for adding and configuring the light
 *  sources for the 3D scene. Each light uses the ambient,
 *  diffuse and specular parts of the Phong lighting model.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// tell the shaders to render the 3D scene with custom lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// light 1 - warm colored point light just under the tall lamp's shade,
	// acting as the bulb so it lights up the desk around the lamp
	m_pShaderManager->setVec3Value("lightSources[0].position", -6.0f, 4.0f, -2.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.15f, 0.1f, 0.02f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.8f, 0.6f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.8f, 0.6f, 0.3f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.4f);

	// light 2 - soft white fill light above and in front of the desk so
	// the fronts of all the objects stay lit as the camera moves around
	m_pShaderManager->setVec3Value("lightSources[1].position", 0.0f, 10.0f, 10.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.4f, 0.4f, 0.4f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f);

	// light 3 - cool blue point light in front of the monitor to act
	// as the glow from the screen
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 4.5f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.0f, 0.02f, 0.06f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.2f, 0.3f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.2f, 0.3f, 0.6f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.2f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures for the 3D scene
	LoadSceneTextures();
	// define the materials for the objects in the scene
	DefineObjectMaterials();
	// add and configure the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  calling the method that draws each object on the desk
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderDesk();
	RenderLamp();
	RenderMonitor();
	RenderKeyboard();
	RenderMushroomLamp();
	RenderConsole();
	RenderCandle();
}

/***********************************************************
 *  RenderDesk()
 *
 *  This method draws the desk surface as a single plane
 *  that every other object sits on.
 ***********************************************************/
void SceneManager::RenderDesk()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// tile the wood 4 times across and 2 times deep so the grain
	// keeps a natural size instead of stretching across the long desk
	SetTextureUVScale(4.0f, 2.0f);
	SetShaderTexture("desk");
	// wood material lets the light reflect off the desk surface
	SetShaderMaterial("wood");

	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderLamp()
 *
 *  This method draws the tall table lamp on the left side of
 *  the desk. It is built from four basic shapes stacked on
 *  top of each other: a torus lip at the bottom, a flattened
 *  sphere for the domed base, a thin cylinder for the pole,
 *  and a tapered cylinder for the shade.
 ***********************************************************/
void SceneManager::RenderLamp()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// small lip around the very bottom of the base
	scaleXYZ = glm::vec3(1.2f, 1.2f, 1.2f);
	// torus is upright by default so rotate it flat onto the desk
	XrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-6.0f, 0.15f, -2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// tile the gold 3 times around the ring so the brushed lines
	// stay fine instead of stretching around the whole circle
	SetTextureUVScale(3.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawTorusMesh();

	// domed base, squashed vertically so it sits low like the real lamp
	scaleXYZ = glm::vec3(1.3f, 0.8f, 1.3f);
	XrotationDegrees = 0.0f;
	// sphere is centered on its origin, so raising it by its
	// height keeps the whole base above the desk surface
	positionXYZ = glm::vec3(-6.0f, 0.8f, -2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// circular brushed gold, mapped once so the pattern is not repeated
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("goldbase");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawSphereMesh();

	// thin pole running from the base up to the shade
	scaleXYZ = glm::vec3(0.12f, 5.5f, 0.12f);
	// cylinder sits on its own base, so it starts just inside the top of the dome
	positionXYZ = glm::vec3(-6.0f, 1.4f, -2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// same gold as the lip so the metal parts match
	SetShaderTexture("gold");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawCylinderMesh();

	// shade at the top, wide at the bottom and narrow at the top
	scaleXYZ = glm::vec3(2.4f, 2.4f, 2.4f);
	// placed near the top of the pole so the pole disappears inside it
	positionXYZ = glm::vec3(-6.0f, 4.6f, -2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// soft white texture gives the shade a fabric look
	SetShaderTexture("shade");
	SetShaderMaterial("fabric");

	m_basicMeshes->DrawTaperedCylinderMesh();
}

/***********************************************************
 *  RenderMonitor()
 *
 *  This method draws the monitor in the middle of the desk.
 *  It is built from a box clamp, a cylinder post, a flat box
 *  frame, a thin box for the screen and a thin box light bar
 *  on top.
 ***********************************************************/
void SceneManager::RenderMonitor()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// clamp holding the monitor arm at the back of the desk
	scaleXYZ = glm::vec3(0.8f, 0.4f, 0.8f);
	// box is centered on its origin, so it is raised by half its height
	positionXYZ = glm::vec3(0.0f, 0.2f, -3.6f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("metal");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawBoxMesh();

	// vertical post of the monitor arm
	scaleXYZ = glm::vec3(0.15f, 4.0f, 0.15f);
	positionXYZ = glm::vec3(0.0f, 0.4f, -3.6f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("metal");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawCylinderMesh();

	// monitor frame, flattened along Z so it is thin like a real monitor
	scaleXYZ = glm::vec3(6.0f, 3.4f, 0.3f);
	positionXYZ = glm::vec3(0.0f, 5.0f, -3.3f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// dark gray plastic color for the frame
	SetShaderColor(0.15f, 0.15f, 0.17f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

	// screen panel sitting just in front of the frame
	scaleXYZ = glm::vec3(5.6f, 3.0f, 0.05f);
	positionXYZ = glm::vec3(0.0f, 5.0f, -3.13f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("screen");
	SetShaderMaterial("glass");

	m_basicMeshes->DrawBoxMesh();

	// light bar resting on the top edge of the monitor
	scaleXYZ = glm::vec3(2.0f, 0.15f, 0.3f);
	positionXYZ = glm::vec3(0.0f, 6.78f, -3.2f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderKeyboard()
 *
 *  This method draws the keyboard in front of the monitor as
 *  a single flat box.
 ***********************************************************/
void SceneManager::RenderKeyboard()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(5.0f, 0.25f, 1.6f);
	positionXYZ = glm::vec3(0.0f, 0.125f, 1.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// dark gray plastic like the monitor frame
	SetShaderColor(0.2f, 0.2f, 0.22f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderMushroomLamp()
 *
 *  This method draws the small gold mushroom lamp to the
 *  right of the monitor, built from a flat cylinder base, a
 *  thin cylinder stem and a flattened sphere for the shade.
 ***********************************************************/
void SceneManager::RenderMushroomLamp()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// flat round base
	scaleXYZ = glm::vec3(0.6f, 0.15f, 0.6f);
	positionXYZ = glm::vec3(4.5f, 0.0f, -2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("gold");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawCylinderMesh();

	// thin stem rising from the base
	scaleXYZ = glm::vec3(0.12f, 1.5f, 0.12f);
	positionXYZ = glm::vec3(4.5f, 0.15f, -2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("gold");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawCylinderMesh();

	// domed shade, squashed vertically to look like a mushroom cap
	scaleXYZ = glm::vec3(1.1f, 0.6f, 1.1f);
	positionXYZ = glm::vec3(4.5f, 1.9f, -2.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("goldbase");
	SetShaderMaterial("gold");

	m_basicMeshes->DrawSphereMesh();
}

/***********************************************************
 *  RenderConsole()
 *
 *  This method draws the game console on the right side of
 *  the desk as a low, wide box.
 ***********************************************************/
void SceneManager::RenderConsole()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(2.6f, 0.6f, 1.8f);
	// turned slightly so it does not sit perfectly square to the desk
	YrotationDegrees = -10.0f;
	positionXYZ = glm::vec3(7.0f, 0.3f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// light gray plastic
	SetShaderColor(0.8f, 0.8f, 0.82f, 1.0f);
	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderCandle()
 *
 *  This method draws the frosted glass candle in the front
 *  right corner of the desk as a short cylinder.
 ***********************************************************/
void SceneManager::RenderCandle()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.5f);
	positionXYZ = glm::vec3(7.0f, 0.0f, 2.8f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// frosted white glass
	SetShaderColor(0.9f, 0.9f, 0.88f, 1.0f);
	SetShaderMaterial("glass");

	m_basicMeshes->DrawCylinderMesh();
}
